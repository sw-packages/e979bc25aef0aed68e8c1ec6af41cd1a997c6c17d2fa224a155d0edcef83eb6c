#ifndef _RE2C_UTIL_GET_DIR_
#define _RE2C_UTIL_GET_DIR_

#include <string>


namespace re2c {

void get_dir(std::string &path);

} // namespace re2c

#endif // _RE2C_UTIL_GET_DIR_
